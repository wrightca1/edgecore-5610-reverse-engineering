TARGETS = mountkernfs.sh mountdevsubfs.sh bootlogd mstpd mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking ledmgrd switchd pwmd smond urandom checkroot.sh hw_init kmod hostname.sh procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors phy_ucode_update stop-bootlogd-single
INTERACTIVE = checkroot.sh checkfs.sh
mountdevsubfs.sh: mountkernfs.sh
bootlogd: mountdevsubfs.sh
mstpd: rsyslog mountall.sh mountall-bootclean.sh
mountall.sh: checkfs.sh checkroot-bootclean.sh
mountall-bootclean.sh: mountall.sh
mountnfs.sh: mountall.sh mountall-bootclean.sh networking
mountnfs-bootclean.sh: mountall.sh mountall-bootclean.sh mountnfs.sh
arp_refresh: rsyslog hwclock.sh mountall.sh mountall-bootclean.sh networking
rsyslog: checkroot.sh hwclock.sh
hwclock.sh: mountdevsubfs.sh bootlogd
networking: mountkernfs.sh mountall.sh mountall-bootclean.sh urandom mstpd switchd aclinit
ledmgrd: mstpd mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking switchd urandom mountdevsubfs.sh checkroot.sh hw_init kmod mountkernfs.sh hostname.sh bootlogd procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors
switchd: hw_init rsyslog hwclock.sh mountall.sh mountall-bootclean.sh
pwmd: mstpd mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking switchd urandom mountdevsubfs.sh checkroot.sh hw_init kmod mountkernfs.sh hostname.sh bootlogd procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors
smond: mstpd mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking switchd urandom mountdevsubfs.sh checkroot.sh hw_init kmod mountkernfs.sh hostname.sh bootlogd procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors
urandom: mountall.sh mountall-bootclean.sh hwclock.sh
checkroot.sh: hwclock.sh mountdevsubfs.sh hostname.sh bootlogd
hw_init: kmod
kmod: checkroot.sh
hostname.sh: bootlogd
procps: bootlogd mountkernfs.sh mountall.sh mountall-bootclean.sh
checkroot-bootclean.sh: checkroot.sh
bootmisc.sh: checkroot-bootclean.sh mountall-bootclean.sh mountnfs-bootclean.sh mountall.sh mountnfs.sh
mtab.sh: checkroot.sh
checkfs.sh: checkroot.sh mtab.sh
aclinit: rsyslog hwclock.sh
lm-sensors: mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh
phy_ucode_update: mstpd mountall.sh mountall-bootclean.sh mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking switchd urandom mountdevsubfs.sh checkroot.sh hw_init kmod mountkernfs.sh hostname.sh bootlogd procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors
stop-bootlogd-single: mountall.sh mountall-bootclean.sh mstpd mountnfs.sh mountnfs-bootclean.sh arp_refresh rsyslog hwclock.sh networking switchd urandom mountdevsubfs.sh checkroot.sh hw_init kmod mountkernfs.sh hostname.sh bootlogd procps checkroot-bootclean.sh bootmisc.sh mtab.sh checkfs.sh aclinit lm-sensors
